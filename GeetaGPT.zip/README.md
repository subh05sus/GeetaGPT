# ChatGPT-API-Flask-Website
Use ChatGPT API gpt-3.5-turbo and python Flask to build a interactive chat website：

My Chinese installation blog: http://t.csdn.cn/wXnOa

![image](https://user-images.githubusercontent.com/47026637/222842366-6240c87f-c4d3-40e6-8120-356863f4cfaa.png)
